package com.example.claudechat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatLine(val role: String, val text: String)

class ChatVm : ViewModel() {
    var lines by mutableStateOf(listOf<ChatLine>())
        private set
    var input by mutableStateOf("")
    var apiKey by mutableStateOf("")
    var model by mutableStateOf("claude-sonnet-5-5")
    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var showSettings by mutableStateOf(false)

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    fun newChat() {
        lines = emptyList()
        error = null
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        if (apiKey.isBlank()) {
            showSettings = true
            error = "Сначала добавь API-ключ в настройках."
            return
        }
        input = ""
        lines = lines + ChatLine("user", text) + ChatLine("assistant", "")
        error = null
        busy = true
        viewModelScope.launch {
            try {
                val history = lines.dropLast(1)
                val messages = JSONArray()
                history.forEach { line ->
                    if (line.text.isNotBlank()) {
                        messages.put(JSONObject().put("role", line.role).put("content", line.text))
                    }
                }
                val body = JSONObject()
                    .put("model", model)
                    .put("max_tokens", 4096)
                    .put("stream", false)
                    .put("messages", messages)
                    .toString()
                    .toRequestBody("application/json; charset=utf-8".toMediaType())

                val request = Request.Builder()
                    .url("https://api.anthropic.com/v1/messages")
                    .header("x-api-key", apiKey.trim())
                    .header("anthropic-version", "2023-06-01")
                    .header("content-type", "application/json")
                    .post(body)
                    .build()

                val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    http.newCall(request).execute().use { response ->
                        val raw = response.body?.string().orEmpty()
                        if (!response.isSuccessful) {
                            val message = try {
                                JSONObject(raw).optJSONObject("error")?.optString("message")
                            } catch (_: Exception) { null }
                            throw IOException("Ошибка ${response.code}: ${message ?: raw.take(300)}")
                        }
                        val content = JSONObject(raw).optJSONArray("content")
                        buildString {
                            if (content != null) {
                                for (i in 0 until content.length()) {
                                    val block = content.optJSONObject(i)
                                    if (block?.optString("type") == "text") {
                                        append(block.optString("text"))
                                    }
                                }
                            }
                        }.ifBlank { "Claude не вернул текстовый ответ." }
                    }
                }
                lines = lines.dropLast(1) + ChatLine("assistant", result)
            } catch (e: Exception) {
                lines = lines.dropLast(1)
                error = e.message ?: "Не удалось выполнить запрос."
            } finally {
                busy = false
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClaudeChatApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClaudeChatApp(vm: ChatVm = viewModel()) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFD6A77A),
            background = Color(0xFF111111),
            surface = Color(0xFF1B1B1B)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Claude Chat", fontWeight = FontWeight.SemiBold) },
                    actions = {
                        IconButton(onClick = { vm.newChat() }) {
                            Icon(Icons.Default.Add, contentDescription = "Новый чат")
                        }
                        IconButton(onClick = { vm.showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Настройки")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF171717),
                        titleContentColor = Color.White,
                        actionIconContentColor = Color.White
                    )
                )
            },
            containerColor = Color(0xFF111111)
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)
            ) {
                val listState = rememberLazyListState()
                LaunchedEffect(vm.lines.size, vm.busy) {
                    if (vm.lines.isNotEmpty()) listState.animateScrollToItem(vm.lines.lastIndex)
                }
                if (vm.lines.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Привет! Я Claude.", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                            Spacer(Modifier.height(8.dp))
                            Text("Напиши сообщение, чтобы начать разговор.", color = Color.LightGray)
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(vm.lines) { _, line ->
                            val user = line.role == "user"
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
                            ) {
                                Surface(
                                    color = if (user) Color(0xFF34302B) else Color(0xFF202020),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.widthIn(max = 330.dp)
                                ) {
                                    Text(
                                        line.text.ifBlank { if (vm.busy) "Claude печатает…" else "" },
                                        Modifier.padding(13.dp),
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                vm.error?.let {
                    Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(vertical = 6.dp))
                }

                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Surface(
                        color = Color(0xFF242424),
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        BasicTextField(
                            value = vm.input,
                            onValueChange = { vm.input = it },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                            textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                            decorationBox = { inner ->
                                Box {
                                    if (vm.input.isEmpty()) Text("Сообщение Claude…", color = Color.Gray)
                                    inner()
                                }
                            }
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = { vm.send() },
                        enabled = !vm.busy && vm.input.isNotBlank()
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Отправить")
                    }
                }
            }
        }

        if (vm.showSettings) {
            AlertDialog(
                onDismissRequest = { vm.showSettings = false },
                title = { Text("Настройки подключения") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Вставь API-ключ Anthropic. Он используется только на этом устройстве.")
                        OutlinedTextField(
                            value = vm.apiKey,
                            onValueChange = { vm.apiKey = it },
                            label = { Text("Anthropic API key") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                        Text("Модель")
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(
                            expanded = expanded,
                            onExpandedChange = { expanded = !expanded }
                        ) {
                            OutlinedTextField(
                                value = if (vm.model.contains("opus")) "Claude Opus 5.5" else "Claude Sonnet 5.5",
                                onValueChange = {},
                                readOnly = true,
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                DropdownMenuItem(
                                    text = { Text("Claude Sonnet 5.5") },
                                    onClick = { vm.model = "claude-sonnet-5-5"; expanded = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("Claude Opus 5.5") },
                                    onClick = { vm.model = "claude-opus-5-5"; expanded = false }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { vm.showSettings = false }) { Text("Сохранить") }
                },
                dismissButton = {
                    TextButton(onClick = { vm.showSettings = false }) { Text("Закрыть") }
                }
            )
        }
    }
}
